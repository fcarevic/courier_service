package junit.framework;

public interface Protectable {
  void protect() throws Throwable;
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\junit\framework\Protectable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */