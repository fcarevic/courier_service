package junit.framework;

public interface Test {
  int countTestCases();
  
  void run(TestResult paramTestResult);
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\junit\framework\Test.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */