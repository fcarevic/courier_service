/*    */ package junit.runner;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Version
/*    */ {
/*    */   public static String id() {
/* 12 */     return "4.12";
/*    */   }
/*    */   
/*    */   public static void main(String[] args) {
/* 16 */     System.out.println(id());
/*    */   }
/*    */ }


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\junit\runner\Version.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */