package org.junit.internal;

import java.io.PrintStream;

public interface JUnitSystem {
  @Deprecated
  void exit(int paramInt);
  
  PrintStream out();
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\internal\JUnitSystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */