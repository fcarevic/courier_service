package org.junit.internal.runners;

@Deprecated
class FailedBefore extends Exception {
  private static final long serialVersionUID = 1L;
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\internal\runners\FailedBefore.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */