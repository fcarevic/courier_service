package org.junit.runner;

public interface Describable {
  Description getDescription();
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\runner\Describable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */