package org.junit.runner.manipulation;

public interface Filterable {
  void filter(Filter paramFilter) throws NoTestsRemainException;
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\runner\manipulation\Filterable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */