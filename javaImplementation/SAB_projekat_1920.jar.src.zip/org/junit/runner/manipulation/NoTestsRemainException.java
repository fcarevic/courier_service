package org.junit.runner.manipulation;

public class NoTestsRemainException extends Exception {
  private static final long serialVersionUID = 1L;
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\runner\manipulation\NoTestsRemainException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */