package org.junit.runner.manipulation;

public interface Sortable {
  void sort(Sorter paramSorter);
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\runner\manipulation\Sortable.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */