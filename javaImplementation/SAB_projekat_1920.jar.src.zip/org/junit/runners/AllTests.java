/*    */ package org.junit.runners;
/*    */ 
/*    */ import org.junit.internal.runners.SuiteMethod;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class AllTests
/*    */   extends SuiteMethod
/*    */ {
/*    */   public AllTests(Class<?> klass) throws Throwable {
/* 25 */     super(klass);
/*    */   }
/*    */ }


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\runners\AllTests.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */