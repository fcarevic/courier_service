package org.junit.runners.model;

public interface RunnerScheduler {
  void schedule(Runnable paramRunnable);
  
  void finished();
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\runners\model\RunnerScheduler.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */