package org.junit.runners.model;

public abstract class Statement {
  public abstract void evaluate() throws Throwable;
}


/* Location:              C:\Users\CAR\Desktop\sab\SAB_projekat_1920\SAB_projekat_1920\SAB_projekat_1920.jar!\org\junit\runners\model\Statement.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */